namespace Calculator_LN
{
    public partial class Form1 : Form
    {

        private Solver solver = new Solver();


        public Form1()
        {
            InitializeComponent();
        }

        //All of the Click methods from every button
        #region ButtonMethods

        //All of the Click methods from each of the number buttons
        #region NumberButtonMethods

        private void Num0Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("0");
        }

        private void Num1Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("1");
        }

        private void Num2Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("2");
        }

        private void Num3Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("3");
        }

        private void Num4Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("4");
        }

        private void Num5Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("5");
        }

        private void Nam6Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("6");
        }

        private void Num7Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("7");
        }

        private void Num8Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("8");
        }

        private void Num9Button_Click(object sender, EventArgs e)
        {
            AppendCharacter("9");
        }

        #endregion

        //All of the Click methods from each of the operators
        #region OperatorButtonMethods

        private void MultiplicationOperatorButton_Click(object sender, EventArgs e)
        {
            AppendCharacter("*");
        }

        private void DivisionOperatorButton_Click(object sender, EventArgs e)
        {
            AppendCharacter("/");
        }

        private void ModulusOperatorButton_Click(object sender, EventArgs e)
        {
            AppendCharacter("%");
        }

        private void AdditionButtonOperator_Click(object sender, EventArgs e)
        {
            AppendCharacter("+");
        }

        private void SubtractionOperatorButton_Click(object sender, EventArgs e)
        {
            AppendCharacter("-");
        }

        private void EqualsOperatorButton_Click(object sender, EventArgs e)
        {
            OutputLabel.Text = Convert.ToString(solver.Solve());
        }

        #endregion

        //Every other Click method
        #region MiscellaneousButtonMethods

        private void ClearButton_Click(object sender, EventArgs e)
        {
            UserInputLabel.Text = string.Empty;
            OutputLabel.Text = string.Empty;
            solver.Clear();
        }

        private void PositiveNegativeButton_Click(object sender, EventArgs e)
        {
            AppendCharacter("--");
        }

        private void DecimalButton_Click(object sender, EventArgs e)
        {
            AppendCharacter(".");
        }

        #endregion

        #endregion



        private void AppendCharacter(string num)
        {
            if(solver.isNewEquation == true)
            {
                UserInputLabel.Text = string.Empty;
            }
            //Annoying check for the doulbe minus sign and the label
            if(num == "--")
            {
                UserInputLabel.Text += "-";
            }
            else
            {
                UserInputLabel.Text += num;
            }
            solver.Accumulate(num);
        }
    }
}