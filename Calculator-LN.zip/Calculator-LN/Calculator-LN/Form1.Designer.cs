﻿namespace Calculator_LN
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Num0Button = new System.Windows.Forms.Button();
            this.Num7Button = new System.Windows.Forms.Button();
            this.Num8Button = new System.Windows.Forms.Button();
            this.Num9Button = new System.Windows.Forms.Button();
            this.Num4Button = new System.Windows.Forms.Button();
            this.Num1Button = new System.Windows.Forms.Button();
            this.Num5Button = new System.Windows.Forms.Button();
            this.Nam6Button = new System.Windows.Forms.Button();
            this.Num2Button = new System.Windows.Forms.Button();
            this.Num3Button = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.PositiveNegativeButton = new System.Windows.Forms.Button();
            this.ModulusOperatorButton = new System.Windows.Forms.Button();
            this.DecimalButton = new System.Windows.Forms.Button();
            this.DivisionOperatorButton = new System.Windows.Forms.Button();
            this.AdditionButtonOperator = new System.Windows.Forms.Button();
            this.SubtractionOperatorButton = new System.Windows.Forms.Button();
            this.MultiplicationOperatorButton = new System.Windows.Forms.Button();
            this.EqualsOperatorButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.UserInputLabel = new System.Windows.Forms.Label();
            this.DashedLineLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Num0Button
            // 
            this.Num0Button.Location = new System.Drawing.Point(73, 314);
            this.Num0Button.Name = "Num0Button";
            this.Num0Button.Size = new System.Drawing.Size(104, 23);
            this.Num0Button.TabIndex = 0;
            this.Num0Button.Text = "0";
            this.Num0Button.UseVisualStyleBackColor = true;
            this.Num0Button.Click += new System.EventHandler(this.Num0Button_Click);
            // 
            // Num7Button
            // 
            this.Num7Button.Location = new System.Drawing.Point(73, 273);
            this.Num7Button.Name = "Num7Button";
            this.Num7Button.Size = new System.Drawing.Size(33, 23);
            this.Num7Button.TabIndex = 1;
            this.Num7Button.Text = "7";
            this.Num7Button.UseVisualStyleBackColor = true;
            this.Num7Button.Click += new System.EventHandler(this.Num7Button_Click);
            // 
            // Num8Button
            // 
            this.Num8Button.Location = new System.Drawing.Point(144, 273);
            this.Num8Button.Name = "Num8Button";
            this.Num8Button.Size = new System.Drawing.Size(33, 23);
            this.Num8Button.TabIndex = 2;
            this.Num8Button.Text = "8";
            this.Num8Button.UseVisualStyleBackColor = true;
            this.Num8Button.Click += new System.EventHandler(this.Num8Button_Click);
            // 
            // Num9Button
            // 
            this.Num9Button.Location = new System.Drawing.Point(221, 273);
            this.Num9Button.Name = "Num9Button";
            this.Num9Button.Size = new System.Drawing.Size(33, 23);
            this.Num9Button.TabIndex = 3;
            this.Num9Button.Text = "9";
            this.Num9Button.UseVisualStyleBackColor = true;
            this.Num9Button.Click += new System.EventHandler(this.Num9Button_Click);
            // 
            // Num4Button
            // 
            this.Num4Button.Location = new System.Drawing.Point(73, 229);
            this.Num4Button.Name = "Num4Button";
            this.Num4Button.Size = new System.Drawing.Size(33, 23);
            this.Num4Button.TabIndex = 4;
            this.Num4Button.Text = "4";
            this.Num4Button.UseVisualStyleBackColor = true;
            this.Num4Button.Click += new System.EventHandler(this.Num4Button_Click);
            // 
            // Num1Button
            // 
            this.Num1Button.Location = new System.Drawing.Point(73, 188);
            this.Num1Button.Name = "Num1Button";
            this.Num1Button.Size = new System.Drawing.Size(33, 23);
            this.Num1Button.TabIndex = 5;
            this.Num1Button.Text = "1";
            this.Num1Button.UseVisualStyleBackColor = true;
            this.Num1Button.Click += new System.EventHandler(this.Num1Button_Click);
            // 
            // Num5Button
            // 
            this.Num5Button.Location = new System.Drawing.Point(144, 229);
            this.Num5Button.Name = "Num5Button";
            this.Num5Button.Size = new System.Drawing.Size(33, 23);
            this.Num5Button.TabIndex = 6;
            this.Num5Button.Text = "5";
            this.Num5Button.UseVisualStyleBackColor = true;
            this.Num5Button.Click += new System.EventHandler(this.Num5Button_Click);
            // 
            // Nam6Button
            // 
            this.Nam6Button.Location = new System.Drawing.Point(221, 229);
            this.Nam6Button.Name = "Nam6Button";
            this.Nam6Button.Size = new System.Drawing.Size(33, 23);
            this.Nam6Button.TabIndex = 7;
            this.Nam6Button.Text = "6";
            this.Nam6Button.UseVisualStyleBackColor = true;
            this.Nam6Button.Click += new System.EventHandler(this.Nam6Button_Click);
            // 
            // Num2Button
            // 
            this.Num2Button.Location = new System.Drawing.Point(144, 188);
            this.Num2Button.Name = "Num2Button";
            this.Num2Button.Size = new System.Drawing.Size(33, 23);
            this.Num2Button.TabIndex = 8;
            this.Num2Button.Text = "2";
            this.Num2Button.UseVisualStyleBackColor = true;
            this.Num2Button.Click += new System.EventHandler(this.Num2Button_Click);
            // 
            // Num3Button
            // 
            this.Num3Button.Location = new System.Drawing.Point(221, 188);
            this.Num3Button.Name = "Num3Button";
            this.Num3Button.Size = new System.Drawing.Size(33, 23);
            this.Num3Button.TabIndex = 9;
            this.Num3Button.Text = "3";
            this.Num3Button.UseVisualStyleBackColor = true;
            this.Num3Button.Click += new System.EventHandler(this.Num3Button_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(73, 145);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(43, 23);
            this.ClearButton.TabIndex = 10;
            this.ClearButton.Text = "AC";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // PositiveNegativeButton
            // 
            this.PositiveNegativeButton.Location = new System.Drawing.Point(144, 145);
            this.PositiveNegativeButton.Name = "PositiveNegativeButton";
            this.PositiveNegativeButton.Size = new System.Drawing.Size(43, 23);
            this.PositiveNegativeButton.TabIndex = 11;
            this.PositiveNegativeButton.Text = "+/-";
            this.PositiveNegativeButton.UseVisualStyleBackColor = true;
            this.PositiveNegativeButton.Click += new System.EventHandler(this.PositiveNegativeButton_Click);
            // 
            // ModulusOperatorButton
            // 
            this.ModulusOperatorButton.Location = new System.Drawing.Point(221, 145);
            this.ModulusOperatorButton.Name = "ModulusOperatorButton";
            this.ModulusOperatorButton.Size = new System.Drawing.Size(33, 23);
            this.ModulusOperatorButton.TabIndex = 12;
            this.ModulusOperatorButton.Text = "%";
            this.ModulusOperatorButton.UseVisualStyleBackColor = true;
            this.ModulusOperatorButton.Click += new System.EventHandler(this.ModulusOperatorButton_Click);
            // 
            // DecimalButton
            // 
            this.DecimalButton.Location = new System.Drawing.Point(221, 314);
            this.DecimalButton.Name = "DecimalButton";
            this.DecimalButton.Size = new System.Drawing.Size(33, 23);
            this.DecimalButton.TabIndex = 13;
            this.DecimalButton.Text = ".";
            this.DecimalButton.UseVisualStyleBackColor = true;
            this.DecimalButton.Click += new System.EventHandler(this.DecimalButton_Click);
            // 
            // DivisionOperatorButton
            // 
            this.DivisionOperatorButton.Location = new System.Drawing.Point(289, 145);
            this.DivisionOperatorButton.Name = "DivisionOperatorButton";
            this.DivisionOperatorButton.Size = new System.Drawing.Size(33, 23);
            this.DivisionOperatorButton.TabIndex = 14;
            this.DivisionOperatorButton.Text = "/";
            this.DivisionOperatorButton.UseVisualStyleBackColor = true;
            this.DivisionOperatorButton.Click += new System.EventHandler(this.DivisionOperatorButton_Click);
            // 
            // AdditionButtonOperator
            // 
            this.AdditionButtonOperator.Location = new System.Drawing.Point(289, 188);
            this.AdditionButtonOperator.Name = "AdditionButtonOperator";
            this.AdditionButtonOperator.Size = new System.Drawing.Size(33, 23);
            this.AdditionButtonOperator.TabIndex = 15;
            this.AdditionButtonOperator.Text = "+";
            this.AdditionButtonOperator.UseVisualStyleBackColor = true;
            this.AdditionButtonOperator.Click += new System.EventHandler(this.AdditionButtonOperator_Click);
            // 
            // SubtractionOperatorButton
            // 
            this.SubtractionOperatorButton.Location = new System.Drawing.Point(289, 229);
            this.SubtractionOperatorButton.Name = "SubtractionOperatorButton";
            this.SubtractionOperatorButton.Size = new System.Drawing.Size(33, 23);
            this.SubtractionOperatorButton.TabIndex = 16;
            this.SubtractionOperatorButton.Text = "-";
            this.SubtractionOperatorButton.UseVisualStyleBackColor = true;
            this.SubtractionOperatorButton.Click += new System.EventHandler(this.SubtractionOperatorButton_Click);
            // 
            // MultiplicationOperatorButton
            // 
            this.MultiplicationOperatorButton.Location = new System.Drawing.Point(289, 273);
            this.MultiplicationOperatorButton.Name = "MultiplicationOperatorButton";
            this.MultiplicationOperatorButton.Size = new System.Drawing.Size(33, 23);
            this.MultiplicationOperatorButton.TabIndex = 17;
            this.MultiplicationOperatorButton.Text = "x";
            this.MultiplicationOperatorButton.UseVisualStyleBackColor = true;
            this.MultiplicationOperatorButton.Click += new System.EventHandler(this.MultiplicationOperatorButton_Click);
            // 
            // EqualsOperatorButton
            // 
            this.EqualsOperatorButton.Location = new System.Drawing.Point(289, 314);
            this.EqualsOperatorButton.Name = "EqualsOperatorButton";
            this.EqualsOperatorButton.Size = new System.Drawing.Size(33, 23);
            this.EqualsOperatorButton.TabIndex = 18;
            this.EqualsOperatorButton.Text = "=";
            this.EqualsOperatorButton.UseVisualStyleBackColor = true;
            this.EqualsOperatorButton.Click += new System.EventHandler(this.EqualsOperatorButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.OutputLabel);
            this.panel1.Controls.Add(this.UserInputLabel);
            this.panel1.Controls.Add(this.DashedLineLabel);
            this.panel1.Location = new System.Drawing.Point(73, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(488, 100);
            this.panel1.TabIndex = 20;
            // 
            // OutputLabel
            // 
            this.OutputLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.OutputLabel.Location = new System.Drawing.Point(0, 67);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.OutputLabel.Size = new System.Drawing.Size(474, 23);
            this.OutputLabel.TabIndex = 2;
            this.OutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UserInputLabel
            // 
            this.UserInputLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.UserInputLabel.Location = new System.Drawing.Point(0, 19);
            this.UserInputLabel.Name = "UserInputLabel";
            this.UserInputLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.UserInputLabel.Size = new System.Drawing.Size(474, 23);
            this.UserInputLabel.TabIndex = 1;
            this.UserInputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // DashedLineLabel
            // 
            this.DashedLineLabel.AutoSize = true;
            this.DashedLineLabel.Location = new System.Drawing.Point(413, 43);
            this.DashedLineLabel.Name = "DashedLineLabel";
            this.DashedLineLabel.Size = new System.Drawing.Size(72, 15);
            this.DashedLineLabel.TabIndex = 0;
            this.DashedLineLabel.Text = "-------------";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 398);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.EqualsOperatorButton);
            this.Controls.Add(this.MultiplicationOperatorButton);
            this.Controls.Add(this.SubtractionOperatorButton);
            this.Controls.Add(this.AdditionButtonOperator);
            this.Controls.Add(this.DivisionOperatorButton);
            this.Controls.Add(this.DecimalButton);
            this.Controls.Add(this.ModulusOperatorButton);
            this.Controls.Add(this.PositiveNegativeButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.Num3Button);
            this.Controls.Add(this.Num2Button);
            this.Controls.Add(this.Nam6Button);
            this.Controls.Add(this.Num5Button);
            this.Controls.Add(this.Num1Button);
            this.Controls.Add(this.Num4Button);
            this.Controls.Add(this.Num9Button);
            this.Controls.Add(this.Num8Button);
            this.Controls.Add(this.Num7Button);
            this.Controls.Add(this.Num0Button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Button Num0Button;
        private Button Num7Button;
        private Button Num8Button;
        private Button Num9Button;
        private Button Num4Button;
        private Button Num1Button;
        private Button Num5Button;
        private Button Nam6Button;
        private Button Num2Button;
        private Button Num3Button;
        private Button ClearButton;
        private Button PositiveNegativeButton;
        private Button ModulusOperatorButton;
        private Button DecimalButton;
        private Button DivisionOperatorButton;
        private Button AdditionButtonOperator;
        private Button SubtractionOperatorButton;
        private Button MultiplicationOperatorButton;
        private Button EqualsOperatorButton;
        private Panel panel1;
        private Label OutputLabel;
        private Label UserInputLabel;
        private Label DashedLineLabel;
    }
}