﻿public class Solver : ISolve
{
    //List of each part of the equation
    private List<string> equation = new List<string>();

    //A string to store a number in
    string fullNum = "";
    
    //Just a bool to check if we are on a new equation
    public bool isNewEquation = true;

    public void Accumulate(string s)
    {
        //Has to clear it here cause I can't clear it at the end the Solve method
        if (isNewEquation)
        {
            equation.Clear();
            fullNum = "";
            isNewEquation = false;
        }
        //Check for what "s" is
        if (s == "*" || s == "/" || s == "%" || s == "+" || s == "-")
        {
            equation.Add(fullNum);
            fullNum = "";
            equation.Add(s);
        }
        else if(s == "--")
        {
            fullNum += "-";
        }
        else
        {
            fullNum += s;
        }
    }

    //Make sure that all of the fields are empty, and that we are starting a new equation
    public void Clear()
    {
        fullNum = "";
        isNewEquation = true;
        equation.Clear();
    }

    //This method is broken up into several methods. This method just searches for each symbol and returns the final answer
    public double Solve()
    {
        equation.Add(fullNum);
        while(equation.Count > 0)
        {
            if(equation.Contains("*"))
            {
                SearchForSymbol("*");
                continue;
            }
            else if(equation.Contains("/"))
            {
                SearchForSymbol("/");
                continue;
            }
            else if(equation.Contains("%"))
            {
                SearchForSymbol("%");
                continue;
            }
            else if(equation.Contains("+"))
            {
                SearchForSymbol("+");
                continue;
            }
            else if(equation.Contains("-"))
            {
                SearchForSymbol("-");
                continue;
            }
            else
            {
                break;
            }
        }

        isNewEquation = true;
        return Convert.ToDouble(equation[0]);
    }

    //Search for the first instance of a symbol, the break out of the for loop
    private void SearchForSymbol(string symbol)
    {
        for (int i = 0; i < equation.Count; i++)
        {
            if (equation[i] == symbol)
            {
                double firstNum = Convert.ToDouble(equation[i - 1]);
                double secondNum = Convert.ToDouble(equation[i + 1]);
                char charSymbol = Convert.ToChar(equation[i]);
                double newValue =  PerformArithmetic(firstNum, secondNum, charSymbol);
                equation[i] = Convert.ToString(newValue);
                equation.RemoveAt(i + 1);
                equation.RemoveAt(i - 1);
                break;
            }
        }
    }

    //Perform the given operation, called from SearchForSymbol()
    private double PerformArithmetic (double firstNum, double secondNum, char symbol)
    {
        if(symbol == '*')
        {
            return firstNum * secondNum;
        }
        else if(symbol == '/')
        {
            return firstNum / secondNum;
        }
        else if(symbol == '%')
        {
            return firstNum % secondNum;
        }
        else if(symbol == '+')
        {
            return firstNum + secondNum;
        }
        else if(symbol == '-')
        {
            return firstNum - secondNum;
        }
        else
        {
            Console.WriteLine("ERROR!!");
            return 0.0;
        }
    }
}
